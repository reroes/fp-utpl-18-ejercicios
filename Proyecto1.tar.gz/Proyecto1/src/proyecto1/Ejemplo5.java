/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto1;

/**
 *
 * @author reroes
 */
public class Ejemplo5 {

    public static void main(String[] args) {
        String nombre = "René";
        String apellido = "Elizalde";
        int edad = 34;
        double valor = 200.5;
        
        System.out.printf("%s %s\n\tEdad:%d\n\t$ celular:%.2f\n",
                nombre, apellido.toUpperCase() , edad, valor);
    }
}
